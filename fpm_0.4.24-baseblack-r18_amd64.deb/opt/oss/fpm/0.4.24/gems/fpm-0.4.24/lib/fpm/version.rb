module FPM
  VERSION = "0.4.24"
end
