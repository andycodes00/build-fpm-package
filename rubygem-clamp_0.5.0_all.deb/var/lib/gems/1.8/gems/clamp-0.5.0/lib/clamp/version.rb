module Clamp
  VERSION = "0.5.0".freeze
end
