require File.expand_path(File.dirname(__FILE__) + "/backports/tools")
Backports.require_relative "backports/version"
Backports.require_relative "backports/1.9"
Backports.require_relative "backports/rails"
