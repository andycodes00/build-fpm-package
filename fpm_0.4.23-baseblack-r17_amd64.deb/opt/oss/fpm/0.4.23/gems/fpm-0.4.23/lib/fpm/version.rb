module FPM
  VERSION = "0.4.23"
end
