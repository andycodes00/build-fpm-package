module Cabin
  module Outputs
    module EM; end
  end
  module Mixins; end
  module Emitters; end
  class Metrics; end
end
