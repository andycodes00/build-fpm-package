module Process
  class << self
    public :exec
  end
end