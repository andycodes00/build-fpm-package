module FPM
  VERSION = "0.4.25"
end
