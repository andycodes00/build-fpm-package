class Dir
  Backports.alias_method self, :to_path, :path
end