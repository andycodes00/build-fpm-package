require 'clamp/version'

require 'clamp/command'
