require "fpm/namespace"

class FPM::InvalidPackageConfiguration < StandardError; end
