class RPM
  class File; end
end
