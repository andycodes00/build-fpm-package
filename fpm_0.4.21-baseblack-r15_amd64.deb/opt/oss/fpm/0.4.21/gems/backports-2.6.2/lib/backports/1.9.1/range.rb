class Range
  Backports.alias_method self, :cover?, :include?
end