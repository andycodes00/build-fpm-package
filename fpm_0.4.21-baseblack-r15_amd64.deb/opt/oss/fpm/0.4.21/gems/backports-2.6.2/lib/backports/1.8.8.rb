# require this file to load all the backports up to Ruby 1.8.8

require File.expand_path(File.dirname(__FILE__) + "/tools")
Backports.require_relative "1.8.7"
