module Clamp
  VERSION = "0.3.1".freeze
end
